/*
 * Copyright (C) 2012  SINGCOM Pte Ltd 
 *
 * RCU High Level Access Header
 *
 */

#ifndef _RCUHLACCESS_H_
#define _RCUHLACCESS_H_

#include "Global.h"

void RCUHLInit(void);







#endif
